package AST;

public class ASTNode{
}
